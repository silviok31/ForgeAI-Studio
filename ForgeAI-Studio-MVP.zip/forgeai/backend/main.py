import os, json, re, uuid
from datetime import datetime, timezone
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from sqlalchemy import create_engine, String, Text, Boolean, DateTime
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, Session

DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///./forgeai.db')
engine = create_engine(DATABASE_URL, connect_args={'check_same_thread': False} if DATABASE_URL.startswith('sqlite') else {})
class Base(DeclarativeBase): pass
class Project(Base):
    __tablename__ = 'projects'
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    name: Mapped[str] = mapped_column(String(120))
    description: Mapped[str] = mapped_column(Text)
    html: Mapped[str] = mapped_column(Text)
    published: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc))
Base.metadata.create_all(engine)
app = FastAPI(title='ForgeAI API', version='0.1.0')
app.add_middleware(CORSMiddleware, allow_origins=[x.strip() for x in os.getenv('CORS_ORIGINS','http://localhost:5173').split(',')], allow_methods=['*'], allow_headers=['*'])
class CreateProject(BaseModel):
    name: str
    description: str = ''
class UpdateProject(BaseModel):
    name: str | None = None
    description: str | None = None
    html: str | None = None
class GenerateRequest(BaseModel):
    prompt: str

def serialize(p):
    return {'id':p.id,'name':p.name,'description':p.description,'html':p.html,'published':p.published,'created_at':p.created_at.isoformat()}
def template(name, description):
    from html import escape
    n,d=escape(name),escape(description)
    return f'''<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{n}</title><style>body{{margin:0;font-family:system-ui;background:#0c1020;color:white}}main{{max-width:900px;margin:12vh auto;padding:32px}}h1{{font-size:clamp(2rem,6vw,4rem)}}button{{padding:14px 22px;background:#6366f1;color:white;border:0;border-radius:12px}}</style></head><body><main><p>CRIADO COM FORGEAI</p><h1>{n}</h1><p>{d}</p><button onclick="alert('Seu aplicativo está funcionando!')">Começar</button></main></body></html>'''

def get_project(db, project_id):
    p=db.get(Project, project_id)
    if not p: raise HTTPException(404,'Projeto não encontrado')
    return p
@app.get('/api/health')
def health(): return {'status':'ok'}
@app.get('/api/projects')
def list_projects():
    with Session(engine) as db: return [serialize(p) for p in db.query(Project).order_by(Project.created_at.desc()).all()]
@app.post('/api/projects')
def create_project(data:CreateProject):
    if not data.name.strip(): raise HTTPException(400,'Nome obrigatório')
    p=Project(id=str(uuid.uuid4()),name=data.name.strip(),description=data.description,html=template(data.name,data.description))
    with Session(engine) as db:
        db.add(p); db.commit(); db.refresh(p); return serialize(p)
@app.get('/api/projects/{project_id}')
def read_project(project_id:str):
    with Session(engine) as db: return serialize(get_project(db,project_id))
@app.patch('/api/projects/{project_id}')
def update_project(project_id:str,data:UpdateProject):
    with Session(engine) as db:
        p=get_project(db,project_id)
        for k,v in data.model_dump(exclude_unset=True).items():
            if v is not None: setattr(p,k,v)
        db.commit(); db.refresh(p); return serialize(p)
@app.post('/api/projects/{project_id}/generate')
def generate(project_id:str,data:GenerateRequest):
    with Session(engine) as db:
        p=get_project(db,project_id)
        if not os.getenv('OPENAI_API_KEY'): raise HTTPException(503,'Configure OPENAI_API_KEY no servidor para habilitar a geração por IA')
        from openai import OpenAI
        client=OpenAI()
        response=client.responses.create(model=os.getenv('OPENAI_MODEL','gpt-4.1-mini'),instructions='Gere APENAS um documento HTML completo em português do Brasil com CSS e JavaScript inline. Não use markdown, bibliotecas externas, scripts remotos, iframes ou recursos de rede. Construa uma interface funcional e responsiva. Não inclua código servidor nem solicite dados secretos.',input=f'Nome: {p.name}\nDescrição: {p.description}\nPedido: {data.prompt}')
        html=response.output_text.strip()
        html=re.sub(r'^```(?:html)?\s*|\s*```$', '', html, flags=re.I).strip()
        if not html.lower().startswith('<!doctype html') and not html.lower().startswith('<html'): raise HTTPException(502,'A IA não retornou HTML válido')
        p.html=html; db.commit(); db.refresh(p); return serialize(p)
@app.post('/api/projects/{project_id}/publish')
def publish(project_id:str):
    with Session(engine) as db:
        p=get_project(db,project_id); p.published=True; db.commit(); return {'url':f'/p/{p.id}'}
@app.post('/api/projects/{project_id}/unpublish')
def unpublish(project_id:str):
    with Session(engine) as db:
        p=get_project(db,project_id); p.published=False; db.commit(); return {'published':False}
@app.get('/p/{project_id}',response_class=HTMLResponse)
def public_page(project_id:str):
    with Session(engine) as db:
        p=get_project(db,project_id)
        if not p.published: raise HTTPException(404,'Não publicado')
        return HTMLResponse(p.html,headers={'Content-Security-Policy':"default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; font-src data:; base-uri 'none'; form-action 'none'; frame-ancestors 'none'",'X-Content-Type-Options':'nosniff'})
