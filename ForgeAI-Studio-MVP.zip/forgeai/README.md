# ForgeAI Studio — protótipo full-stack

Plataforma independente de criação de páginas web com IA. Inclui painel de projetos, editor HTML, prévia isolada, geração por OpenAI (opcional), banco de dados SQLite e publicação pública.

## Requisitos
- Python 3.10+
- Node.js 20+

## Backend
```bash
cd backend
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
# Opcional: export OPENAI_API_KEY="sua-chave"
uvicorn main:app --reload --port 8000
```
API: http://localhost:8000/docs

## Frontend (outro terminal)
```bash
cd frontend
npm install
npm run dev
```
Acesse http://localhost:5173.

Para hospedar, defina `VITE_API_URL` com a URL HTTPS pública do backend durante o build, e `CORS_ORIGINS` com a origem HTTPS do frontend. Execute o backend atrás de HTTPS.

## Limitações e segurança
- **Protótipo para desenvolvimento local**, não um serviço multiusuário pronto para produção.
- Não há autenticação, isolamento entre usuários, quotas, moderação, auditoria nem cobrança. **Não publique a API na internet sem implementar esses controles.**
- O editor salva HTML/JS livre. A prévia usa iframe sandbox; a publicação usa CSP restritiva, mas aplicações com código de terceiros devem ser hospedadas em domínio isolado, com revisão de segurança.
- A geração por IA requer chave própria e pode gerar custos; a chave fica apenas no backend.
- A geração atual cria interfaces HTML/CSS/JS, não cria automaticamente novas tabelas, endpoints nem sistemas complexos com backend.
- SQLite é para testes locais; PostgreSQL, migrations, filas e armazenamento externo são recomendados para produção.
